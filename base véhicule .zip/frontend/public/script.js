const nativeFetch = window.fetch.bind(window);
let csrfTokenPromise = null;

async function getCsrfToken() {
  csrfTokenPromise ||= nativeFetch("/api/csrf-token", { credentials: "include" })
    .then((response) => response.json())
    .then((data) => data.csrfToken);
  return csrfTokenPromise;
}

window.fetch = async (input, options = {}) => {
  const method = (options.method || "GET").toUpperCase();
  const headers = new Headers(options.headers || {});

  if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
    headers.set("X-CSRF-Token", await getCsrfToken());
  }

  return nativeFetch(input, {
    ...options,
    headers,
    credentials: "include",
  });
};

const authNavButton = document.querySelector("#auth-nav-button");
const brandHomeButton = document.querySelector("#brand-home-button");
const navHomeButton = document.querySelector("#nav-home-button");
const navDashboardButton = document.querySelector("#nav-dashboard-button");
const navUserName = document.querySelector("#nav-user-name");
const logoutButton = document.querySelector("#logout-button");
const homePage = document.querySelector("#home-page");
const dashboardPage = document.querySelector("#dashboard-page");
const dashboardTitle = document.querySelector("#dashboard-title");
const statFolders = document.querySelector("#stat-folders");
const statVehicles = document.querySelector("#stat-vehicles");
const statTodolists = document.querySelector("#stat-todolists");
const homeAuthButton = document.querySelector("#home-auth-button");
const openProjectDashboard = document.querySelector("#open-project-dashboard");
const appShell = document.querySelector("#app-shell");
const backDashboardButton = document.querySelector("#back-dashboard-button");
const folderMenu = document.querySelector("#folder-menu");
const toggleSidebar = document.querySelector("#toggle-sidebar");
const openCreateFolderModal = document.querySelector("#open-create-folder-modal");
const createFolderModal = document.querySelector("#create-folder-modal");
const createFolderForm = document.querySelector("#create-folder-form");
const folderNameInput = document.querySelector("#folder-name");
const formMessage = document.querySelector("#form-message");
const addFolderItemModal = document.querySelector("#add-folder-item-modal");
const addFolderItemTitle = document.querySelector("#add-folder-item-title");
const createPageForm = document.querySelector("#create-page-form");
const pageTitleInput = document.querySelector("#page-title");
const pageFormMessage = document.querySelector("#page-form-message");
const deleteFolderModal = document.querySelector("#delete-folder-modal");
const deleteFolderCopy = document.querySelector("#delete-folder-copy");
const deleteFolderMessage = document.querySelector("#delete-folder-message");
const confirmDeleteFolder = document.querySelector("#confirm-delete-folder");
const todoDetailModal = document.querySelector("#todo-detail-modal");
const todoDetailForm = document.querySelector("#todo-detail-form");
const todoDetailText = document.querySelector("#todo-detail-text");
const todoDetailStatus = document.querySelector("#todo-detail-status");
const todoDetailSize = document.querySelector("#todo-detail-size");
const todoDetailDescription = document.querySelector("#todo-detail-description");
const todoDetailMessage = document.querySelector("#todo-detail-message");
const authModal = document.querySelector("#auth-modal");
const authForm = document.querySelector("#auth-form");
const authTitle = document.querySelector("#auth-title");
const authUsername = document.querySelector("#auth-username");
const authEmail = document.querySelector("#auth-email");
const authPassword = document.querySelector("#auth-password");
const authMessage = document.querySelector("#auth-message");
const authSubmit = document.querySelector("#auth-submit");
const toggleAuthMode = document.querySelector("#toggle-auth-mode");
const cancelAuth = document.querySelector("#cancel-auth");
const currentFolder = document.querySelector("#current-folder");
const folderDescription = document.querySelector("#folder-description");
const pageList = document.querySelector("#page-list");

let folders = [];
let activeFolderId = null;
let activePageId = null;
let pageTargetFolderId = null;
let deleteTargetFolderId = null;
let saveTimer = null;
let todoStatusFilter = "all";
let todoDetailTarget = null;
let activeTodoBoard = null;
let activeTodoDraw = null;
let vehicleUiState = {};
let authPromise = null;
let authResolve = null;
let authMode = "login";
let currentUser = null;
let projectsLoaded = false;

const pageTypeLabels = {
  note: "Note",
  todolist: "Todolist",
  vehicle: "Projet vehicule",
};

const todoStatuses = {
  todo: { label: "A faire", color: "red" },
  in_progress: { label: "En cours", color: "orange" },
  done: { label: "Fait", color: "green" },
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function showFormModal(title, fields, onSubmit) {
  const modal = document.createElement("div");
  modal.className = "modal is-open";
  modal.innerHTML = `
    <div class="modal__backdrop" data-close-dynamic-modal></div>
    <section class="modal__window" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}">
      <div class="modal__content">
        <div>
          <p class="eyebrow">Edition</p>
          <h2>${escapeHtml(title)}</h2>
        </div>
        <form class="modal-form" id="dynamic-form">
          ${fields
            .map((field) => {
              const value = escapeHtml(field.value || "");
              const options = field.options || [];
              if (field.type === "textarea") {
                return `
                  <label for="dynamic-${field.name}">${escapeHtml(field.label)}</label>
                  <textarea id="dynamic-${field.name}" name="${field.name}" class="modal-textarea">${value}</textarea>
                `;
              }
              if (field.type === "select") {
                return `
                  <label for="dynamic-${field.name}">${escapeHtml(field.label)}</label>
                  <select id="dynamic-${field.name}" name="${field.name}" class="modal-select">
                    ${options
                      .map(
                        (option) =>
                          `<option value="${escapeHtml(option.value)}" ${String(field.value || "") === option.value ? "selected" : ""}>${escapeHtml(option.label)}</option>`,
                      )
                      .join("")}
                  </select>
                `;
              }
              if (field.type === "checkbox-list") {
                const values = Array.isArray(field.value) ? field.value.map(String) : [];
                return `
                  <fieldset class="vehicle-link-picker">
                    <legend>${escapeHtml(field.label)}</legend>
                    ${
                      options.length
                        ? options
                            .map(
                              (option) => `
                                <label>
                                  <input name="${field.name}" type="checkbox" value="${escapeHtml(option.value)}" ${values.includes(String(option.value)) ? "checked" : ""} />
                                  <span>${escapeHtml(option.label)}</span>
                                </label>
                              `,
                            )
                            .join("")
                        : '<p>Aucune piece disponible.</p>'
                    }
                  </fieldset>
                `;
              }
              return `
                <label for="dynamic-${field.name}">${escapeHtml(field.label)}</label>
                <input id="dynamic-${field.name}" name="${field.name}" type="${field.type || "text"}" value="${value}" ${field.step ? `step="${field.step}"` : ""} ${field.min ? `min="${field.min}"` : ""} />
              `;
            })
            .join("")}
          <p class="form-message" role="status"></p>
          <div class="modal-form__actions">
            <button class="secondary-button" type="button" data-close-dynamic-modal>Annuler</button>
            <button class="primary-button" type="submit">Sauvegarder</button>
          </div>
        </form>
      </div>
      <button class="modal__close" type="button" aria-label="Fermer la fenetre" title="Fermer" data-close-dynamic-modal>x</button>
    </section>
  `;

  function close() {
    modal.remove();
  }

  modal.querySelectorAll("[data-close-dynamic-modal]").forEach((button) => {
    button.addEventListener("click", close);
  });

  modal.querySelector("#dynamic-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await onSubmit(new FormData(event.target));
    close();
  });

  document.body.append(modal);
}

async function parseJsonResponse(response) {
  const contentType = response.headers.get("content-type") || "";

  if (!contentType.includes("application/json")) {
    throw new Error(
      "Le serveur ne renvoie pas du JSON. Lance la page avec server.js, pas avec Live Server ni en ouvrant le fichier directement.",
    );
  }

  return response.json();
}

function getActiveFolder() {
  return folders.find((folder) => folder.id === activeFolderId);
}

function getActivePage() {
  return getActiveFolder()?.pages.find((page) => page.id === activePageId);
}

function normalizeFolder(folder) {
  return {
    ...folder,
    pages: Array.isArray(folder.pages) ? folder.pages : [],
  };
}

function setMessage(element, message, isError = false) {
  element.textContent = message;
  element.classList.toggle("is-error", isError);
}

function createTodoId(text) {
  const slug =
    text
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "tache";

  return `${slug}-${Date.now().toString(36)}`;
}

function createCategoryId(title) {
  const slug =
    title
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "categorie";

  return `${slug}-${Date.now().toString(36)}`;
}

function normalizeTodoContent(content) {
  function normalizeTodo(todo) {
    const status =
      ["todo", "in_progress", "done"].includes(todo.status)
        ? todo.status
        : todo.done
          ? "done"
          : "todo";

    return {
      ...todo,
      status,
      done: status === "done",
      description: todo.description || "",
      size: ["small", "medium", "large"].includes(todo.size)
        ? todo.size
        : "medium",
    };
  }

  if (Array.isArray(content)) {
    return {
      categories: [
        {
          id: "a-faire",
          title: "A faire",
          todos: content.map(normalizeTodo),
        },
      ],
    };
  }

  if (Array.isArray(content?.categories)) {
    return {
      categories: content.categories.map((category) => ({
        id: category.id,
        title: category.title,
        todos: Array.isArray(category.todos)
          ? category.todos.map(normalizeTodo)
          : [],
      })),
    };
  }

  return {
    categories: [
      {
        id: "a-faire",
        title: "A faire",
        todos: [],
      },
    ],
  };
}

function createId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function normalizeVehicleContent(page) {
  const content = page.content && typeof page.content === "object" ? page.content : {};

  return {
    name: content.name || page.title,
    activeTab: content.activeTab || "parts",
    filters: content.filters && typeof content.filters === "object" ? content.filters : {},
    parts: Array.isArray(content.parts) ? content.parts : [],
    jobs: Array.isArray(content.jobs) ? content.jobs : [],
    photos: Array.isArray(content.photos) ? content.photos : [],
    documents: Array.isArray(content.documents) ? content.documents : [],
    history: Array.isArray(content.history) ? content.history : [],
    consumables: Array.isArray(content.consumables) ? content.consumables : [],
    stages: Array.isArray(content.stages)
      ? content.stages
      : [
          { id: "diagnostic", label: "Diagnostic", status: "en-cours", notes: "" },
          { id: "commandes", label: "Commandes", status: "a-faire", notes: "" },
          { id: "demontage", label: "Demontage", status: "a-faire", notes: "" },
          { id: "reparation", label: "Reparation", status: "a-faire", notes: "" },
          { id: "remontage", label: "Remontage", status: "a-faire", notes: "" },
          { id: "tests", label: "Tests", status: "a-faire", notes: "" },
          { id: "controle-technique", label: "Controle technique", status: "a-faire", notes: "" },
        ],
    inspection: Array.isArray(content.inspection)
      ? content.inspection
      : [
          { id: "freinage", label: "Freinage", status: "check", notes: "" },
          { id: "eclairage", label: "Eclairage", status: "check", notes: "" },
          { id: "pneus", label: "Pneus", status: "check", notes: "" },
          { id: "pollution", label: "Pollution", status: "check", notes: "" },
          { id: "direction", label: "Direction", status: "check", notes: "" },
          { id: "suspension", label: "Suspension", status: "check", notes: "" },
          { id: "corrosion", label: "Corrosion", status: "check", notes: "" },
          { id: "visibilite", label: "Visibilite", status: "check", notes: "" },
          { id: "ceintures-airbag", label: "Ceintures / airbag", status: "check", notes: "" },
        ],
    budget: {
      target: Number(content.budget?.target || 0),
    },
  };
}

function renderFolders() {
  folderMenu.innerHTML = "";

  folders.forEach((folder) => {
    const group = document.createElement("div");
    group.className = "folder-menu__group";

    const item = document.createElement("div");
    item.className = "folder-menu__item";
    item.title = folder.name;
    item.dataset.folderId = folder.id;

    if (folder.id === activeFolderId && !activePageId) {
      item.classList.add("is-active");
    }

    item.innerHTML = `
      <button class="folder-menu__main" type="button">
        <span class="folder-menu__icon" aria-hidden="true"></span>
        <span class="folder-menu__label"></span>
      </button>
      <span class="folder-menu__actions">
        <button class="folder-menu__action" type="button" title="Ajouter une page" aria-label="Ajouter une page">+</button>
        <button class="folder-menu__action" type="button" title="Renommer le dossier" aria-label="Renommer le dossier">r</button>
        <button class="folder-menu__action is-danger" type="button" title="Supprimer le dossier" aria-label="Supprimer le dossier">x</button>
      </span>
    `;

    item.querySelector(".folder-menu__label").textContent = folder.name;
    item
      .querySelector(".folder-menu__main")
      .addEventListener("click", () => selectFolder(folder.id));
    item
      .querySelector(".folder-menu__action")
      .addEventListener("click", () => openCreatePageModal(folder.id));
    item
      .querySelectorAll(".folder-menu__action")[1]
      .addEventListener("click", () => renameFolder(folder.id));
    item
      .querySelector(".folder-menu__action.is-danger")
      .addEventListener("click", () => openDeleteFolderModal(folder.id));

    group.append(item);

    const submenu = document.createElement("div");
    submenu.className = "page-submenu";

    folder.pages.forEach((page) => {
      const pageButton = document.createElement("button");
      pageButton.className = "page-submenu__item";
      pageButton.type = "button";
      pageButton.title = page.title;

      if (folder.id === activeFolderId && page.id === activePageId) {
        pageButton.classList.add("is-active");
      }

      pageButton.innerHTML = `
        <span class="page-submenu__icon" aria-hidden="true"></span>
        <span class="page-submenu__label"></span>
        <span class="page-submenu__actions">
          <span class="page-submenu__action" data-page-rename title="Renommer">r</span>
          <span class="page-submenu__action is-danger" data-page-delete title="Supprimer">x</span>
        </span>
      `;
      pageButton.querySelector(".page-submenu__icon").textContent =
        page.type === "note" ? "N" : page.type === "vehicle" ? "V" : "T";
      pageButton.querySelector(".page-submenu__label").textContent = page.title;
      pageButton.addEventListener("click", (event) => {
        if (event.target.hasAttribute("data-page-rename")) {
          event.stopPropagation();
          renamePage(folder.id, page.id);
          return;
        }

        if (event.target.hasAttribute("data-page-delete")) {
          event.stopPropagation();
          deletePage(folder.id, page.id);
          return;
        }

        selectPage(folder.id, page.id);
      });
      submenu.append(pageButton);
    });

    group.append(submenu);
    folderMenu.append(group);
  });
}

function renderPageCards(folder) {
  pageList.classList.remove("is-editor");

  if (!folder.pages.length) {
    pageList.innerHTML =
      '<div class="empty-state">Aucune page pour le moment. Utilisez le bouton + du dossier pour en creer une.</div>';
    return;
  }

  folder.pages.forEach((page) => {
    const card = document.createElement("button");
    card.className = "page-card";
    card.type = "button";
    card.dataset.type = page.type;
    card.innerHTML = `
      <div class="page-card__top">
        <span class="page-card__icon" aria-hidden="true"></span>
        <div>
          <h4></h4>
          <p></p>
        </div>
      </div>
    `;

    card.querySelector(".page-card__icon").textContent =
      page.type === "note" ? "N" : page.type === "vehicle" ? "V" : "T";
    card.querySelector("h4").textContent = page.title;
    card.querySelector("p").textContent = pageTypeLabels[page.type] || "Page";
    card.addEventListener("click", () => selectPage(folder.id, page.id));
    pageList.append(card);
  });
}

function renderNoteEditor(page) {
  pageList.classList.add("is-editor");
  pageList.innerHTML = `
    <form class="page-editor" id="note-editor">
      <label for="note-content">Contenu de la note</label>
      <textarea id="note-content" name="content" placeholder="Ecrire une note..."></textarea>
      <div class="editor-actions">
        <p class="save-status" id="save-status">Pret</p>
        <button class="primary-button" type="submit">Sauvegarder</button>
      </div>
    </form>
  `;

  const form = document.querySelector("#note-editor");
  const textarea = document.querySelector("#note-content");
  const status = document.querySelector("#save-status");

  textarea.value = page.content || "";
  textarea.addEventListener("input", () => {
    status.textContent = "Modification non sauvegardee";
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => form.requestSubmit(), 700);
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    status.textContent = "Sauvegarde...";

    try {
      await updatePage(activeFolderId, activePageId, { content: textarea.value });
      status.textContent = "Sauvegarde";
    } catch (error) {
      status.textContent = error.message;
      status.classList.add("is-error");
    }
  });
}

function renderTodoEditor(page) {
  pageList.classList.add("is-editor");
  const board = normalizeTodoContent(page.content);
  page.content = board;
  activeTodoBoard = board;

  pageList.innerHTML = `
    <section class="todo-editor">
      <div class="todo-toolbar">
        <div class="todo-filter" id="todo-filter" aria-label="Filtrer les taches">
          <button type="button" data-filter="all">Tout</button>
          <button type="button" data-filter="todo">A faire</button>
          <button type="button" data-filter="in_progress">En cours</button>
          <button type="button" data-filter="done">Fait</button>
        </div>
      </div>
      <form class="category-form" id="category-form">
        <label for="category-title">Nouvelle categorie</label>
        <div class="todo-form__row">
          <input id="category-title" type="text" placeholder="Exemple : En cours" autocomplete="off" />
          <button class="primary-button" type="submit">Ajouter</button>
        </div>
      </form>
      <div class="todo-board" id="todo-board"></div>
      <p class="save-status" id="save-status">Pret</p>
    </section>
  `;

  const categoryForm = document.querySelector("#category-form");
  const categoryInput = document.querySelector("#category-title");
  const todoFilter = document.querySelector("#todo-filter");
  let draggedTodo = null;
  let draggedCategoryId = null;

  function updateFilterButtons() {
    todoFilter.querySelectorAll("button").forEach((button) => {
      button.classList.toggle("is-active", button.dataset.filter === todoStatusFilter);
    });
  }

  function findTodoLocation(todoId) {
    for (const category of board.categories) {
      const todoIndex = category.todos.findIndex((todo) => todo.id === todoId);

      if (todoIndex !== -1) {
        return { category, todoIndex };
      }
    }

    return null;
  }

  function renameCategory(category) {
    const title = window.prompt("Nouveau nom de la categorie", category.title);

    if (!title?.trim()) {
      return;
    }

    category.title = title.trim();
    drawBoard();
    saveTodos(board);
  }

  function deleteCategory(categoryId) {
    const category = board.categories.find((item) => item.id === categoryId);

    if (!category) {
      return;
    }

    if (category.todos.length && !window.confirm("Supprimer cette categorie et ses taches ?")) {
      return;
    }

    if (!category.todos.length && !window.confirm("Supprimer cette categorie ?")) {
      return;
    }

    board.categories = board.categories.filter((item) => item.id !== categoryId);

    if (!board.categories.length) {
      board.categories.push({ id: "a-faire", title: "A faire", todos: [] });
    }

    drawBoard();
    saveTodos(board);
  }

  function moveCategory(targetCategoryId) {
    if (!draggedCategoryId || draggedCategoryId === targetCategoryId) {
      return;
    }

    const originIndex = board.categories.findIndex(
      (category) => category.id === draggedCategoryId,
    );
    const targetIndex = board.categories.findIndex(
      (category) => category.id === targetCategoryId,
    );

    if (originIndex === -1 || targetIndex === -1) {
      return;
    }

    const [category] = board.categories.splice(originIndex, 1);
    board.categories.splice(targetIndex, 0, category);
    drawBoard();
    saveTodos(board);
  }

  function moveDraggedTodo(targetCategoryId, beforeTodoId = null) {
    if (!draggedTodo) {
      return;
    }

    if (beforeTodoId === draggedTodo.todoId) {
      return;
    }

    const origin = findTodoLocation(draggedTodo.todoId);
    const targetCategory = board.categories.find(
      (category) => category.id === targetCategoryId,
    );

    if (!origin || !targetCategory) {
      return;
    }

    const [todo] = origin.category.todos.splice(origin.todoIndex, 1);
    const targetIndex = beforeTodoId
      ? targetCategory.todos.findIndex((item) => item.id === beforeTodoId)
      : -1;

    if (targetIndex === -1) {
      targetCategory.todos.push(todo);
    } else {
      targetCategory.todos.splice(targetIndex, 0, todo);
    }

    drawBoard();
    saveTodos(board);
  }

  function drawBoard() {
    const todoBoard = document.querySelector("#todo-board");
    todoBoard.innerHTML = "";

    board.categories.forEach((category) => {
      const column = document.createElement("section");
      column.className = "todo-column";
      column.dataset.categoryId = category.id;
      column.draggable = true;
      column.innerHTML = `
        <div class="todo-column__header">
          <span class="todo-column__grip" aria-hidden="true">::</span>
          <h4></h4>
          <span class="todo-column__count"></span>
          <button class="todo-column__delete" type="button" aria-label="Supprimer la categorie">x</button>
        </div>
        <form class="todo-form">
          <input type="text" placeholder="Ajouter une tache" autocomplete="off" />
          <button type="submit">+</button>
        </form>
        <div class="todo-list"></div>
      `;

      column.querySelector("h4").textContent = category.title;
      const doneCount = category.todos.filter((todo) => todo.status === "done").length;
      column.querySelector(".todo-column__count").textContent =
        `${doneCount}/${category.todos.length}`;
      column.querySelector("h4").addEventListener("dblclick", () => {
        renameCategory(category);
      });
      column.querySelector(".todo-column__delete").addEventListener("click", () => {
        deleteCategory(category.id);
      });
      column.addEventListener("dragstart", (event) => {
        if (event.target.closest(".todo-item")) {
          return;
        }

        draggedCategoryId = category.id;
        column.classList.add("is-dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", category.id);
      });
      column.addEventListener("dragend", () => {
        draggedCategoryId = null;
        column.classList.remove("is-dragging");
      });
      column.addEventListener("dragover", (event) => {
        if (draggedCategoryId) {
          event.preventDefault();
        }
      });
      column.addEventListener("drop", (event) => {
        if (!draggedCategoryId) {
          return;
        }

        event.preventDefault();
        moveCategory(category.id);
      });

      const todoForm = column.querySelector(".todo-form");
      const todoInput = todoForm.querySelector("input");
      const todoList = column.querySelector(".todo-list");

      todoForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const text = todoInput.value.trim();

        if (!text) {
          return;
        }

        category.todos.push({
          id: createTodoId(text),
          text,
          status: "todo",
          done: false,
          description: "",
          size: "medium",
        });
        todoInput.value = "";
        drawBoard();
        saveTodos(board);
      });

      todoList.addEventListener("dragover", (event) => {
        event.preventDefault();
        todoList.classList.add("is-drop-target");
      });

      todoList.addEventListener("dragleave", () => {
        todoList.classList.remove("is-drop-target");
      });

      todoList.addEventListener("drop", (event) => {
        event.preventDefault();
        todoList.classList.remove("is-drop-target");
        moveDraggedTodo(category.id);
      });

      const visibleTodos = todoStatusFilter === "all"
        ? category.todos
        : category.todos.filter((todo) => todo.status === todoStatusFilter);

      if (!visibleTodos.length) {
        todoList.innerHTML = '<div class="todo-empty">Deposer ou ajouter une tache.</div>';
      }

      visibleTodos.forEach((todo) => {
        const row = document.createElement("article");
        row.className = "todo-item";
        row.draggable = true;
        row.dataset.todoId = todo.id;
        row.dataset.status = todo.status;
        row.dataset.size = todo.size || "medium";
        row.innerHTML = `
          <div class="todo-item__top">
            <span class="todo-item__grip" aria-hidden="true">::</span>
            <div class="todo-item__content">
              <span class="todo-item__text"></span>
              <span class="todo-item__description"></span>
            </div>
            <button type="button" aria-label="Supprimer la tache">x</button>
          </div>
          <div class="todo-item__bottom">
            <select class="todo-status" aria-label="Statut de la tache">
              <option value="todo">A faire</option>
              <option value="in_progress">En cours</option>
              <option value="done">Fait</option>
            </select>
          </div>
        `;

        row.querySelector(".todo-status").value = todo.status;
        row.querySelector(".todo-item__text").textContent = todo.text;
        row.querySelector(".todo-item__description").textContent =
          todo.description ? todo.description : "";
        row.classList.toggle("is-done", todo.status === "done");
        row.addEventListener("click", (event) => {
          if (row.classList.contains("is-dragging")) {
            return;
          }

          if (
            event.target.closest("select") ||
            event.target.closest("button") ||
            event.target.closest(".todo-item__grip")
          ) {
            return;
          }

          openTodoDetailModal(category.id, todo.id);
        });

        row.addEventListener("dragstart", (event) => {
          draggedTodo = { todoId: todo.id };
          row.classList.add("is-dragging");
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", todo.id);
        });

        row.addEventListener("dragend", () => {
          draggedTodo = null;
          row.classList.remove("is-dragging");
        });

        row.addEventListener("dragover", (event) => {
          event.preventDefault();
        });

        row.addEventListener("drop", (event) => {
          event.preventDefault();
          event.stopPropagation();
          moveDraggedTodo(category.id, todo.id);
        });

        row.querySelector(".todo-status").addEventListener("change", (event) => {
          todo.status = event.target.value;
          todo.done = todo.status === "done";
          drawBoard();
          saveTodos(board);
        });

        row.querySelector("button").addEventListener("click", () => {
          const index = category.todos.findIndex((item) => item.id === todo.id);
          category.todos.splice(index, 1);
          drawBoard();
          saveTodos(board);
        });

        todoList.append(row);
      });

      todoBoard.append(column);
    });
  }

  categoryForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const title = categoryInput.value.trim();

    if (!title) {
      return;
    }

    board.categories.push({ id: createCategoryId(title), title, todos: [] });
    categoryInput.value = "";
    drawBoard();
    saveTodos(board);
  });

  todoFilter.addEventListener("click", (event) => {
    const button = event.target.closest("button");

    if (!button) {
      return;
    }

    todoStatusFilter = button.dataset.filter;
    updateFilterButtons();
    drawBoard();
  });

  updateFilterButtons();
  activeTodoDraw = drawBoard;
  drawBoard();
}

function renderVehicleEditor(page) {
  pageList.classList.add("is-editor");
  const vehicle = normalizeVehicleContent(page);
  page.content = vehicle;

  const tabs = [
    ["summary", "Resume"],
    ["parts", "Pieces"],
    ["jobs", "Travaux"],
    ["budget", "Budget"],
    ["shopping", "Achats"],
    ["consumables", "Stock"],
    ["planning", "Etapes"],
    ["photos", "Photos"],
    ["inspection", "Controle"],
    ["documents", "Docs"],
    ["history", "Historique"],
    ["export", "Export"],
    ["import", "Import"],
  ];

  const priorityOptions = [
    { value: "securite", label: "Securite" },
    { value: "controle-technique", label: "Controle technique" },
    { value: "fiabilite", label: "Fiabilite" },
    { value: "confort", label: "Confort" },
    { value: "esthetique", label: "Esthetique" },
    { value: "optionnel", label: "Optionnel" },
  ];
  const urgencyOptions = [
    { value: "bloquant", label: "Bloquant" },
    { value: "important", label: "Important" },
    { value: "normal", label: "Normal" },
    { value: "optionnel", label: "Optionnel" },
  ];
  const categoryOptions = [
    { value: "moteur", label: "Moteur" },
    { value: "freinage", label: "Freinage" },
    { value: "carrosserie", label: "Carrosserie" },
    { value: "interieur", label: "Interieur" },
    { value: "electricite", label: "Electricite" },
    { value: "train-roulant", label: "Train roulant" },
    { value: "stock", label: "Stock" },
    { value: "outillage", label: "Outillage" },
    { value: "autre", label: "Autre" },
  ];
  const partStatusOptions = [
    { value: "a-acheter", label: "A acheter" },
    { value: "commande", label: "Commande" },
    { value: "recu", label: "Recu" },
    { value: "monte", label: "Monte" },
    { value: "a-verifier", label: "A verifier" },
  ];
  const jobStatusOptions = [
    { value: "a-faire", label: "A faire" },
    { value: "en-cours", label: "En cours" },
    { value: "fait", label: "Fait" },
    { value: "bloque", label: "Bloque" },
  ];
  const consumableStatusOptions = [
    { value: "a-acheter", label: "A acheter" },
    { value: "commande", label: "Commande" },
    { value: "recu", label: "Recu" },
    { value: "utilise", label: "Utilise" },
  ];

  function money(value) {
    return `${Number(value || 0).toFixed(2)} EUR`;
  }

  function totals() {
    const estimatedParts = vehicle.parts.reduce(
      (sum, part) => sum + Number(part.estimatedPrice || 0) * Number(part.quantity || 1),
      0,
    );
    const realParts = vehicle.parts.reduce(
      (sum, part) => sum + Number(part.realPrice || 0) * Number(part.quantity || 1),
      0,
    );
    const estimatedConsumables = vehicle.consumables.reduce(
      (sum, item) => sum + Number(item.estimatedPrice || 0),
      0,
    );
    return { estimatedParts, realParts, estimatedConsumables };
  }

  function completion() {
    const partDone = vehicle.parts.filter((part) =>
      ["monte", "recu"].includes(part.status),
    ).length;
    const jobDone = vehicle.jobs.filter((job) => job.status === "fait").length;
    const inspectionDone = vehicle.inspection.filter((item) => item.status === "ok").length;
    const total = vehicle.parts.length + vehicle.jobs.length + vehicle.inspection.length;
    const done = partDone + jobDone + inspectionDone;
    return total ? Math.round((done / total) * 100) : 0;
  }

  function addHistory(type, label) {
    vehicle.history.unshift({
      id: createId("history"),
      date: new Date().toISOString(),
      type,
      label,
    });
  }

  async function editPart(partId) {
    const part = vehicle.parts.find((item) => item.id === partId);

    if (!part) return;

    showFormModal(
      "Modifier une piece",
      [
        { name: "name", label: "Nom", value: part.name },
        { name: "quantity", label: "Quantite", type: "number", min: "1", value: part.quantity || 1 },
        { name: "category", label: "Categorie", type: "select", value: part.category || "autre", options: categoryOptions },
        { name: "urgency", label: "Urgence", type: "select", value: part.urgency || "normal", options: urgencyOptions },
        { name: "priority", label: "Priorite", type: "select", value: part.priority || "fiabilite", options: priorityOptions },
        { name: "status", label: "Statut", type: "select", value: part.status || "a-acheter", options: partStatusOptions },
        { name: "reference", label: "Reference", value: part.reference },
        { name: "dimension", label: "Dimension", value: part.dimension },
        { name: "estimatedPrice", label: "Prix estime unite", type: "number", step: "0.01", min: "0", value: part.estimatedPrice || 0 },
        { name: "realPrice", label: "Prix reel unite", type: "number", step: "0.01", min: "0", value: part.realPrice || 0 },
        { name: "link", label: "Lien achat", value: part.link },
        { name: "comment", label: "Commentaire", type: "textarea", value: part.comment },
      ],
      async (data) => {
        part.name = String(data.get("name")).trim() || part.name;
        part.quantity = Number(data.get("quantity") || 1);
        part.category = String(data.get("category"));
        part.urgency = String(data.get("urgency"));
        part.priority = String(data.get("priority"));
        part.status = String(data.get("status"));
        part.reference = String(data.get("reference") || "").trim();
        part.dimension = String(data.get("dimension") || "").trim();
        part.estimatedPrice = Number(data.get("estimatedPrice") || 0);
        part.realPrice = Number(data.get("realPrice") || 0);
        part.link = String(data.get("link") || "").trim();
        part.comment = String(data.get("comment") || "").trim();
        part.blocking = part.urgency === "bloquant";
        addHistory("part", `Piece modifiee: ${part.name}`);
        await saveVehicle();
        render();
      },
    );
  }

  async function editJob(jobId) {
    const job = vehicle.jobs.find((item) => item.id === jobId);

    if (!job) return;

    showFormModal(
      "Modifier un travail",
      [
        { name: "title", label: "Titre", value: job.title },
        { name: "area", label: "Zone", type: "select", value: job.area || "autre", options: categoryOptions },
        { name: "urgency", label: "Urgence", type: "select", value: job.urgency || "normal", options: urgencyOptions },
        { name: "difficulty", label: "Difficulte", type: "select", value: job.difficulty || "moyen", options: [
          { value: "facile", label: "Facile" },
          { value: "moyen", label: "Moyen" },
          { value: "difficile", label: "Difficile" },
        ] },
        { name: "status", label: "Statut", type: "select", value: job.status || "a-faire", options: jobStatusOptions },
        { name: "duration", label: "Duree estimee", value: job.duration },
        { name: "dependencies", label: "Dependances", value: job.dependencies },
        { name: "partIds", label: "Pieces liees", type: "checkbox-list", value: job.partIds || [], options: partOptions() },
        { name: "notes", label: "Notes", type: "textarea", value: job.notes },
      ],
      async (data) => {
        job.title = String(data.get("title")).trim() || job.title;
        job.area = String(data.get("area"));
        job.urgency = String(data.get("urgency"));
        job.difficulty = String(data.get("difficulty"));
        job.status = String(data.get("status"));
        job.duration = String(data.get("duration") || "").trim();
        job.dependencies = String(data.get("dependencies") || "").trim();
        job.partIds = data.getAll("partIds").map(String);
        job.notes = String(data.get("notes") || "").trim();
        job.blocking = job.status === "bloque" || job.urgency === "bloquant";
        addHistory("job", `Travail modifie: ${job.title}`);
        await saveVehicle();
        render();
      },
    );
  }

  async function editConsumable(itemId) {
    const item = vehicle.consumables.find((entry) => entry.id === itemId);
    if (!item) return;

    showFormModal(
      "Modifier un article",
      [
        { name: "name", label: "Nom", value: item.name },
        { name: "quantity", label: "Quantite", value: item.quantity },
        { name: "category", label: "Categorie", type: "select", value: item.category || "autre", options: [
          { value: "fluide", label: "Fluide" },
          { value: "filtre", label: "Filtre" },
          { value: "ampoule", label: "Ampoule" },
          { value: "visserie", label: "Visserie" },
          { value: "clip", label: "Clip / agrafe" },
          { value: "joint", label: "Joint" },
          { value: "nettoyage", label: "Nettoyage" },
          { value: "peinture", label: "Peinture" },
          { value: "abrasif", label: "Abrasif" },
          { value: "autre", label: "Autre" },
        ] },
        { name: "status", label: "Statut", type: "select", value: item.status || "a-acheter", options: consumableStatusOptions },
        { name: "estimatedPrice", label: "Prix estime", type: "number", step: "0.01", min: "0", value: item.estimatedPrice || 0 },
        { name: "link", label: "Lien achat", value: item.link },
        { name: "notes", label: "Notes", type: "textarea", value: item.notes },
      ],
      async (data) => {
        item.name = String(data.get("name")).trim() || item.name;
        item.quantity = String(data.get("quantity") || "").trim();
        item.category = String(data.get("category"));
        item.status = String(data.get("status"));
        item.estimatedPrice = Number(data.get("estimatedPrice") || 0);
        item.link = String(data.get("link") || "").trim();
        item.notes = String(data.get("notes") || "").trim();
        addHistory("consumable", `Stock modifie: ${item.name}`);
        await saveVehicle();
        render();
      },
    );
  }

  async function editPhoto(photoId) {
    const photo = vehicle.photos.find((entry) => entry.id === photoId);
    if (!photo) return;

    showFormModal(
      "Modifier une photo",
      [
        { name: "label", label: "Titre", value: photo.label },
        { name: "url", label: "Chemin ou URL", value: photo.url },
        { name: "linkedTo", label: "Lien", type: "select", value: photo.linkedTo || "", options: [
          { value: "", label: "Lie a rien" },
          ...linkedOptions().map((option) => {
            const [type, id, label] = option.split(":");
            return { value: `${type}:${id}`, label: `${type} - ${label}` };
          }),
        ] },
        { name: "category", label: "Categorie", type: "select", value: photo.category || "avant", options: [
          { value: "avant", label: "Avant" },
          { value: "apres", label: "Apres" },
          { value: "piece", label: "Piece" },
          { value: "travail", label: "Travail" },
        ] },
        { name: "notes", label: "Notes", type: "textarea", value: photo.notes },
      ],
      async (data) => {
        photo.label = String(data.get("label")).trim() || photo.label;
        photo.url = String(data.get("url")).trim();
        photo.linkedTo = String(data.get("linkedTo") || "");
        photo.category = String(data.get("category"));
        photo.notes = String(data.get("notes") || "").trim();
        addHistory("photo", `Photo modifiee: ${photo.label}`);
        await saveVehicle();
        render();
      },
    );
  }

  async function editDocument(docId) {
    const doc = vehicle.documents.find((entry) => entry.id === docId);
    if (!doc) return;

    showFormModal(
      "Modifier un document",
      [
        { name: "label", label: "Nom", value: doc.label },
        { name: "url", label: "Chemin ou URL", value: doc.url },
        { name: "type", label: "Type", type: "select", value: doc.type || "autre", options: [
          { value: "facture", label: "Facture" },
          { value: "reference", label: "Reference" },
          { value: "manuel", label: "Manuel" },
          { value: "schema", label: "Schema" },
          { value: "autre", label: "Autre" },
        ] },
        { name: "notes", label: "Notes", type: "textarea", value: doc.notes },
      ],
      async (data) => {
        doc.label = String(data.get("label")).trim() || doc.label;
        doc.url = String(data.get("url")).trim();
        doc.type = String(data.get("type"));
        doc.notes = String(data.get("notes") || "").trim();
        addHistory("document", `Document modifie: ${doc.label}`);
        await saveVehicle();
        render();
      },
    );
  }

  function linkedOptions() {
    return [
      ...vehicle.parts.map((part) => `piece:${part.id}:${part.name}`),
      ...vehicle.jobs.map((job) => `travail:${job.id}:${job.title}`),
    ];
  }

  function priorityLabel(value) {
    return {
      securite: "Securite",
      "controle-technique": "Controle technique",
      fiabilite: "Fiabilite",
      confort: "Confort",
      esthetique: "Esthetique",
      optionnel: "Optionnel",
    }[value] || value;
  }

  function partStatusLabel(value) {
    return {
      "a-acheter": "A acheter",
      commande: "Commande",
      recu: "Recu",
      monte: "Monte",
      "a-verifier": "A verifier",
    }[value] || value;
  }

  function jobStatusLabel(value) {
    return {
      "a-faire": "A faire",
      "en-cours": "En cours",
      fait: "Fait",
      bloque: "Bloque",
    }[value] || value;
  }

  function inspectionStatusLabel(value) {
    return {
      ok: "OK",
      to_fix: "A corriger",
      blocking: "Bloquant",
      check: "A verifier",
    }[value] || value;
  }

  function urgencyLabel(value) {
    return {
      bloquant: "Bloquant",
      important: "Important",
      normal: "Normal",
      optionnel: "Optionnel",
    }[value] || value || "Normal";
  }

  function categoryLabel(value) {
    return {
      moteur: "Moteur",
      freinage: "Freinage",
      carrosserie: "Carrosserie",
      interieur: "Interieur",
      electricite: "Electricite",
      "train-roulant": "Train roulant",
      stock: "Stock",
      outillage: "Outillage",
      autre: "Autre",
    }[value] || value || "Autre";
  }

  function partOptions() {
    return vehicle.parts.map((part) => ({
      value: part.id,
      label: `${part.name} - ${partStatusLabel(part.status || "a-acheter")}`,
    }));
  }

  function linkedParts(job) {
    const ids = Array.isArray(job.partIds) ? job.partIds.map(String) : [];
    return vehicle.parts.filter((part) => ids.includes(String(part.id)));
  }

  function renderLinkedParts(job) {
    const parts = linkedParts(job);

    if (!parts.length) {
      return '<p class="vehicle-linked-parts is-empty">Aucune piece liee.</p>';
    }

    return `
      <div class="vehicle-linked-parts">
        <span>Pieces liees</span>
        <div>
          ${parts
            .map(
              (part) => `
                <span class="vehicle-soft-pill">
                  ${escapeHtml(part.name)} · ${partStatusLabel(part.status || "a-acheter")}
                </span>
              `,
            )
            .join("")}
        </div>
      </div>
    `;
  }

  function getUiState() {
    const key = `${page.id}:${vehicle.activeTab}`;
    vehicleUiState[key] ||= {
      query: "",
      status: "all",
      category: "all",
      priority: "all",
      urgency: "all",
    };
    return vehicleUiState[key];
  }

  function renderFilterBar(body, type) {
    const state = getUiState();
    const statusOptions =
      type === "jobs"
        ? jobStatusOptions
        : type === "stock"
          ? consumableStatusOptions
          : partStatusOptions;
    const filterCategoryOptions =
      type === "stock"
        ? [
            { value: "fluide", label: "Fluide" },
            { value: "filtre", label: "Filtre" },
            { value: "ampoule", label: "Ampoule" },
            { value: "visserie", label: "Visserie" },
            { value: "clip", label: "Clip / agrafe" },
            { value: "joint", label: "Joint" },
            { value: "nettoyage", label: "Nettoyage" },
            { value: "peinture", label: "Peinture" },
            { value: "abrasif", label: "Abrasif" },
            { value: "autre", label: "Autre" },
          ]
        : categoryOptions;

    body.insertAdjacentHTML(
      "afterbegin",
      `
        <form class="vehicle-filter" id="vehicle-filter-form">
          <div class="vehicle-filter__search">
            <span aria-hidden="true">⌕</span>
            <input name="query" value="${escapeHtml(state.query)}" placeholder="Rechercher..." />
          </div>
          <details class="vehicle-filter__more">
            <summary>Filtres</summary>
            <div class="vehicle-filter__grid">
              <label>
                <span>Statut</span>
                <select name="status">
                  <option value="all">Tous les statuts</option>
                  ${statusOptions
                    .map((option) => `<option value="${option.value}" ${state.status === option.value ? "selected" : ""}>${option.label}</option>`)
                    .join("")}
                </select>
              </label>
              <label>
                <span>Categorie</span>
                <select name="category">
                  <option value="all">Toutes categories</option>
                  ${filterCategoryOptions
                    .map((option) => `<option value="${option.value}" ${state.category === option.value ? "selected" : ""}>${option.label}</option>`)
                    .join("")}
                </select>
              </label>
              <label>
                <span>Priorite</span>
                <select name="priority">
                  <option value="all">Toutes priorites</option>
                  ${priorityOptions
                    .map((option) => `<option value="${option.value}" ${state.priority === option.value ? "selected" : ""}>${option.label}</option>`)
                    .join("")}
                </select>
              </label>
              <label>
                <span>Urgence</span>
                <select name="urgency">
                  <option value="all">Toutes urgences</option>
                  ${urgencyOptions
                    .map((option) => `<option value="${option.value}" ${state.urgency === option.value ? "selected" : ""}>${option.label}</option>`)
                    .join("")}
                </select>
              </label>
            </div>
          </details>
        </form>
      `,
    );

    body.querySelector("#vehicle-filter-form").addEventListener("input", (event) => {
      const data = new FormData(event.currentTarget);
      state.query = String(data.get("query") || "").toLowerCase().trim();
      state.status = String(data.get("status") || "all");
      state.category = String(data.get("category") || "all");
      state.priority = String(data.get("priority") || "all");
      state.urgency = String(data.get("urgency") || "all");
      renderVehicleTab();
    });
  }

  function matchesVehicleFilters(item, type) {
    const state = getUiState();
    const haystack = Object.values(item)
      .join(" ")
      .toLowerCase();
    const category = type === "jobs" ? item.area : item.category;

    return (
      (!state.query || haystack.includes(state.query)) &&
      (state.status === "all" || item.status === state.status) &&
      (state.category === "all" || category === state.category) &&
      (type !== "jobs" && type !== "stock" ? state.priority === "all" || item.priority === state.priority : true) &&
      (type !== "stock" ? state.urgency === "all" || item.urgency === state.urgency : true)
    );
  }

  function parseVehicleNote(text) {
    let section = "";
    const lines = text
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);
    let importedParts = 0;
    let importedJobs = 0;
    let importedChecks = 0;

    lines.forEach((line) => {
      const normalized = line
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toUpperCase();

      if (normalized.includes("PIECE A CHANGER") || normalized.includes("PIECES")) {
        section = "parts";
        return;
      }

      if (normalized.includes("A REPARE")) {
        section = "jobs";
        return;
      }

      if (normalized.includes("AUTRES")) {
        section = "checks";
        return;
      }

      const cleanLine = line.replace(/^[-*•\s]+/, "").trim();

      if (!cleanLine) {
        return;
      }

      if (section === "parts") {
        const quantityMatch = cleanLine.match(/^x(\d+)\s+/i);
        const quantity = quantityMatch ? Number(quantityMatch[1]) : 1;
        const name = cleanLine.replace(/^x\d+\s+/i, "").trim();
        const isOption = /option/i.test(cleanLine);
        const priority = /frein|pneu|airbag|roulement|direction|distribution|embrayage|flexible/i.test(cleanLine)
          ? "securite"
          : isOption
            ? "optionnel"
            : "fiabilite";
        const category = /frein|plaquette|disque|flexible/i.test(cleanLine)
          ? "freinage"
          : /rouille|bas de caisse|polissage|coque|porte|coffre/i.test(cleanLine)
            ? "carrosserie"
            : /airbag|enceinte|autoradio|faisceau|ampoule|demarreur/i.test(cleanLine)
              ? "electricite"
              : /pneu|roulement|biellette|amortisseur/i.test(cleanLine)
                ? "train-roulant"
                : /filtre|bougie|distribution|embrayage|catalyseur/i.test(cleanLine)
                  ? "moteur"
                  : "autre";
        const urgency = priority === "securite" ? "important" : isOption ? "optionnel" : "normal";

        vehicle.parts.push({
          id: createId("part"),
          name,
          quantity,
          reference: cleanLine.match(/ref\s*:?\s*([A-Za-z0-9]+)/i)?.[1] || "",
          dimension: cleanLine.match(/\b\d{3}\/\d{2}\s*R\d{2}\b/i)?.[0] || "",
          category,
          urgency,
          priority,
          status: "a-acheter",
          estimatedPrice: 0,
          realPrice: 0,
          link: "",
          comment: isOption ? "Optionnel" : "",
        });
        importedParts += 1;
        return;
      }

      if (section === "jobs") {
        vehicle.jobs.push({
          id: createId("job"),
          title: cleanLine,
          area: /ciel|plafonnier|boite|enceinte/i.test(cleanLine)
            ? "interieur"
            : /masse|lumiere|ampoule/i.test(cleanLine)
              ? "electricite"
              : "autre",
          urgency: "normal",
          difficulty: "moyen",
          duration: "",
          status: "a-faire",
          dependencies: "",
          notes: "",
        });
        importedJobs += 1;
        return;
      }

      vehicle.inspection.push({
        id: createId("check"),
        label: cleanLine,
        status: "check",
        notes: "",
      });
      importedChecks += 1;
    });

    addHistory(
      "import",
      `Import note: ${importedParts} pieces, ${importedJobs} travaux, ${importedChecks} controles`,
    );
  }

  async function saveVehicle() {
    await updatePage(activeFolderId, activePageId, { content: vehicle });
  }

  function render() {
    const { estimatedParts, realParts, estimatedConsumables } = totals();
    pageList.innerHTML = `
      <section class="vehicle-page">
        <div class="vehicle-summary">
          <div>
            <p class="eyebrow">Projet vehicule</p>
            <h3>${vehicle.name}</h3>
            <div class="vehicle-progress">
              <span style="width: ${completion()}%"></span>
            </div>
          </div>
          <div class="vehicle-metrics">
            <span><strong>${completion()}%</strong> termine</span>
            <span><strong>${vehicle.parts.filter((part) => part.status === "a-acheter").length}</strong> achats</span>
            <span><strong>${vehicle.jobs.filter((job) => job.status !== "fait").length}</strong> travaux</span>
            <span><strong>${money(estimatedParts + estimatedConsumables)}</strong> budget</span>
          </div>
        </div>
        <div class="vehicle-tabs">
          ${tabs
            .map(
              ([id, label]) =>
                `<button type="button" data-tab="${id}" class="${vehicle.activeTab === id ? "is-active" : ""}">${label}</button>`,
            )
            .join("")}
        </div>
        <div class="vehicle-body" id="vehicle-body"></div>
      </section>
    `;

    document.querySelectorAll(".vehicle-tabs button").forEach((button) => {
      button.addEventListener("click", async () => {
        vehicle.activeTab = button.dataset.tab;
        await saveVehicle();
        render();
      });
    });

    renderVehicleTab();
  }

  function renderVehicleTab() {
    const body = document.querySelector("#vehicle-body");

    if (vehicle.activeTab === "summary") {
      const { estimatedParts, realParts, estimatedConsumables } = totals();
      const blockers = [
        ...vehicle.jobs.filter((job) => job.status === "bloque").map((job) => job.title),
        ...vehicle.inspection.filter((item) => item.status === "blocking").map((item) => item.label),
      ];
      body.innerHTML = `
        <div class="budget-grid">
          <div><span>Avancement global</span><strong>${completion()}%</strong></div>
          <div><span>Pieces a acheter</span><strong>${vehicle.parts.filter((part) => part.status === "a-acheter").length}</strong></div>
          <div><span>Travaux restants</span><strong>${vehicle.jobs.filter((job) => job.status !== "fait").length}</strong></div>
          <div><span>Budget estime</span><strong>${money(estimatedParts + estimatedConsumables)}</strong></div>
          <div><span>Budget reel</span><strong>${money(realParts)}</strong></div>
          <div><span>Points bloquants</span><strong>${blockers.length}</strong></div>
        </div>
        <div class="vehicle-cards">
          <article class="vehicle-card">
            <h4>Priorites securite</h4>
            <p>${vehicle.parts.filter((part) => part.priority === "securite" && part.status !== "monte").map((part) => part.name).join(", ") || "Aucune"}</p>
          </article>
          <article class="vehicle-card">
            <h4>Bloquants</h4>
            <p>${blockers.join(", ") || "Aucun"}</p>
          </article>
          <article class="vehicle-card">
            <h4>Derniers evenements</h4>
            <p>${vehicle.history.slice(0, 5).map((entry) => entry.label).join(" / ") || "Aucun historique"}</p>
          </article>
        </div>
      `;
      return;
    }

    if (vehicle.activeTab === "parts") {
      body.innerHTML = `
        <div class="vehicle-section-head">
          <div>
            <h4>Pieces</h4>
            <p>${vehicle.parts.length} piece${vehicle.parts.length > 1 ? "s" : ""} suivie${vehicle.parts.length > 1 ? "s" : ""}</p>
          </div>
          <button class="primary-button" id="toggle-part-form" type="button">+ Ajouter une piece</button>
        </div>
        <form class="vehicle-form vehicle-form--panel" id="part-form" hidden>
          <div class="vehicle-form__group vehicle-form__group--main">
            <label>
              <span>Piece</span>
              <input name="name" placeholder="Ex: Plaquettes avant" required />
            </label>
            <label>
              <span>Quantite</span>
              <input name="quantity" type="number" min="1" value="1" title="Quantite" />
            </label>
          </div>
          <div class="vehicle-form__group">
            <label>
              <span>Categorie</span>
              <select name="category">
                <option value="moteur">Moteur</option>
                <option value="freinage">Freinage</option>
                <option value="carrosserie">Carrosserie</option>
                <option value="interieur">Interieur</option>
                <option value="electricite">Electricite</option>
                <option value="train-roulant">Train roulant</option>
                <option value="stock">Stock</option>
                <option value="outillage">Outillage</option>
                <option value="autre">Autre</option>
              </select>
            </label>
            <label>
              <span>Urgence</span>
              <select name="urgency">
                <option value="important">Important</option>
                <option value="bloquant">Bloquant</option>
                <option value="normal">Normal</option>
                <option value="optionnel">Optionnel</option>
              </select>
            </label>
            <label>
              <span>Priorite</span>
              <select name="priority">
                <option value="securite">Securite</option>
                <option value="controle-technique">Controle technique</option>
                <option value="fiabilite">Fiabilite</option>
                <option value="confort">Confort</option>
                <option value="esthetique">Esthetique</option>
                <option value="optionnel">Optionnel</option>
              </select>
            </label>
            <label>
              <span>Statut</span>
              <select name="status">
                <option value="a-acheter">A acheter</option>
                <option value="commande">Commande</option>
                <option value="recu">Recu</option>
                <option value="monte">Monte</option>
                <option value="a-verifier">A verifier</option>
              </select>
            </label>
          </div>
          <details class="vehicle-form__details">
            <summary>Infos achat et references</summary>
            <div class="vehicle-form__group">
              <label>
                <span>Reference</span>
                <input name="reference" placeholder="Reference constructeur" />
              </label>
              <label>
                <span>Dimension</span>
                <input name="dimension" placeholder="Dimension / taille" />
              </label>
              <label>
                <span>Prix estime</span>
                <input name="estimatedPrice" type="number" min="0" step="0.01" placeholder="0.00" />
              </label>
              <label>
                <span>Prix reel</span>
                <input name="realPrice" type="number" min="0" step="0.01" placeholder="0.00" />
              </label>
              <label>
                <span>Lien achat</span>
                <input name="link" placeholder="https://..." />
              </label>
              <label>
                <span>Commentaire</span>
                <input name="comment" placeholder="Note rapide" />
              </label>
            </div>
          </details>
          <div class="vehicle-form__actions">
            <button class="secondary-button" id="cancel-part-form" type="button">Annuler</button>
            <button class="primary-button" type="submit">Ajouter la piece</button>
          </div>
        </form>
        <div class="vehicle-table">
          ${vehicle.parts
            .filter((part) => matchesVehicleFilters(part, "parts"))
            .map(
              (part) => `
                <article class="vehicle-row vehicle-part-card">
                  <strong>${part.name}</strong>
                  <span>Qté ${part.quantity || 1}</span>
                  <span>${part.reference || "Sans ref"}</span>
                  <span>${part.dimension || ""}</span>
                  <span>${categoryLabel(part.category)}</span>
                  <span>${urgencyLabel(part.urgency)}</span>
                  <span class="priority-pill" data-priority="${part.priority || "fiabilite"}">${priorityLabel(part.priority || "fiabilite")}</span>
                  <span class="status-pill" data-status="${part.status || "a-acheter"}">${partStatusLabel(part.status || "a-acheter")}</span>
                  <span>${money(Number(part.estimatedPrice || 0) * Number(part.quantity || 1))}</span>
                  <span>${part.blocking ? "Bloquant" : ""}</span>
                  <button type="button" data-edit-part="${part.id}">Editer</button>
                  <button type="button" data-delete-part="${part.id}">Supprimer</button>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucune piece ajoutee.</div>'}
        </div>
      `;
      renderFilterBar(body, "parts");

      const partForm = document.querySelector("#part-form");
      const togglePartForm = document.querySelector("#toggle-part-form");
      togglePartForm.addEventListener("click", () => {
        partForm.hidden = false;
        togglePartForm.hidden = true;
        partForm.querySelector("input[name='name']").focus();
      });
      document.querySelector("#cancel-part-form").addEventListener("click", () => {
        partForm.reset();
        partForm.hidden = true;
        togglePartForm.hidden = false;
      });

      document.querySelector("#part-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(event.target);
        vehicle.parts.push({
          id: createId("part"),
          name: String(data.get("name")).trim(),
          quantity: Number(data.get("quantity") || 1),
          reference: String(data.get("reference") || "").trim(),
          dimension: String(data.get("dimension") || "").trim(),
          category: String(data.get("category")),
          urgency: String(data.get("urgency")),
          priority: String(data.get("priority")),
          status: String(data.get("status")),
          estimatedPrice: Number(data.get("estimatedPrice") || 0),
          realPrice: Number(data.get("realPrice") || 0),
          link: String(data.get("link") || "").trim(),
          comment: String(data.get("comment") || "").trim(),
          blocking: String(data.get("urgency")) === "bloquant",
        });
        addHistory("part", `Piece ajoutee: ${String(data.get("name")).trim()}`);
        await saveVehicle();
        render();
      });

      body.querySelectorAll("[data-delete-part]").forEach((button) => {
        button.addEventListener("click", async () => {
          vehicle.parts = vehicle.parts.filter((part) => part.id !== button.dataset.deletePart);
          addHistory("part", "Piece supprimee");
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-edit-part]").forEach((button) => {
        button.addEventListener("click", () => editPart(button.dataset.editPart));
      });
      return;
    }

    if (vehicle.activeTab === "jobs") {
      body.innerHTML = `
        <form class="vehicle-form" id="job-form">
          <input name="title" placeholder="Intervention / reparation" required />
          <select name="area">
            <option value="moteur">Moteur</option>
            <option value="freinage">Freinage</option>
            <option value="carrosserie">Carrosserie</option>
            <option value="interieur">Interieur</option>
            <option value="electricite">Electricite</option>
            <option value="train-roulant">Train roulant</option>
            <option value="outillage">Outillage</option>
            <option value="autre">Autre</option>
          </select>
          <select name="urgency">
            <option value="important">Important</option>
            <option value="bloquant">Bloquant</option>
            <option value="normal">Normal</option>
            <option value="optionnel">Optionnel</option>
          </select>
          <select name="difficulty">
            <option value="facile">Facile</option>
            <option value="moyen">Moyen</option>
            <option value="difficile">Difficile</option>
          </select>
          <input name="duration" placeholder="Duree estimee" />
          <input name="dependencies" placeholder="A faire avant / dependances" />
          <select name="status">
            <option value="a-faire">A faire</option>
            <option value="en-cours">En cours</option>
            <option value="fait">Fait</option>
            <option value="bloque">Bloque</option>
          </select>
          <fieldset class="vehicle-link-picker">
            <legend>Pieces liees au travail</legend>
            ${
              vehicle.parts.length
                ? vehicle.parts
                    .map(
                      (part) => `
                        <label>
                          <input name="partIds" type="checkbox" value="${escapeHtml(part.id)}" />
                          <span>${escapeHtml(part.name)} - ${partStatusLabel(part.status || "a-acheter")}</span>
                        </label>
                      `,
                    )
                    .join("")
                : '<p>Ajoutez d abord des pieces dans l onglet Pieces.</p>'
            }
          </fieldset>
          <textarea name="notes" placeholder="Notes"></textarea>
          <button class="primary-button" type="submit">Ajouter</button>
        </form>
        <div class="vehicle-cards">
          ${vehicle.jobs
            .filter((job) => matchesVehicleFilters(job, "jobs"))
            .map(
              (job) => `
                <article class="vehicle-card">
                  <h4>${job.title}</h4>
                  <p><span class="status-pill" data-status="${job.status || "a-faire"}">${jobStatusLabel(job.status || "a-faire")}</span></p>
                  <p>${categoryLabel(job.area)} / ${urgencyLabel(job.urgency)} / ${job.difficulty}</p>
                  <p>${job.duration || ""}</p>
                  <p>${job.dependencies ? `Dependances: ${job.dependencies}` : ""}</p>
                  ${renderLinkedParts(job)}
                  <p>${job.blocking ? "Bloquant" : ""}</p>
                  <p>${job.notes || ""}</p>
                  <button type="button" data-edit-job="${job.id}">Editer</button>
                  <button type="button" data-delete-job="${job.id}">Supprimer</button>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucun travail ajoute.</div>'}
        </div>
      `;
      renderFilterBar(body, "jobs");

      document.querySelector("#job-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(event.target);
        vehicle.jobs.push({
          id: createId("job"),
          title: String(data.get("title")).trim(),
          area: String(data.get("area")),
          urgency: String(data.get("urgency")),
          difficulty: String(data.get("difficulty")),
          duration: String(data.get("duration") || "").trim(),
          status: String(data.get("status")),
          dependencies: String(data.get("dependencies") || "").trim(),
          partIds: data.getAll("partIds").map(String),
          notes: String(data.get("notes") || "").trim(),
          blocking: String(data.get("status")) === "bloque" || String(data.get("urgency")) === "bloquant",
        });
        addHistory("job", `Travail ajoute: ${String(data.get("title")).trim()}`);
        await saveVehicle();
        render();
      });

      body.querySelectorAll("[data-delete-job]").forEach((button) => {
        button.addEventListener("click", async () => {
          vehicle.jobs = vehicle.jobs.filter((job) => job.id !== button.dataset.deleteJob);
          addHistory("job", "Travail supprime");
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-edit-job]").forEach((button) => {
        button.addEventListener("click", () => editJob(button.dataset.editJob));
      });
      return;
    }

    if (vehicle.activeTab === "budget") {
      body.innerHTML = `
        <div class="budget-grid">
          <div><span>Budget max</span><strong>${money(vehicle.budget.target)}</strong></div>
          <div><span>Pieces estimees</span><strong>${money(estimatedParts)}</strong></div>
          <div><span>Stock</span><strong>${money(estimatedConsumables)}</strong></div>
          <div><span>Pieces reel</span><strong>${money(realParts)}</strong></div>
          <div><span>Reste estime</span><strong>${money(Number(vehicle.budget.target || 0) - estimatedParts - estimatedConsumables)}</strong></div>
        </div>
        <form class="vehicle-form vehicle-form--inline" id="budget-form">
          <input name="target" type="number" min="0" step="0.01" value="${vehicle.budget.target || 0}" />
          <button class="primary-button" type="submit">Mettre a jour</button>
        </form>
      `;

      document.querySelector("#budget-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        vehicle.budget.target = Number(new FormData(event.target).get("target") || 0);
        await saveVehicle();
        render();
      });
      return;
    }

    if (vehicle.activeTab === "shopping") {
      const partsToBuy = vehicle.parts.filter((part) =>
        ["a-acheter", "commande", "a-verifier"].includes(part.status),
      );
      const consumablesToBuy = vehicle.consumables.filter((item) =>
        ["a-acheter", "commande"].includes(item.status),
      );
      body.innerHTML = `
        <div class="vehicle-cards">
          ${[...partsToBuy, ...consumablesToBuy]
            .map(
              (item) => `
                <article class="vehicle-card">
                  <h4>${item.name}</h4>
                  <p>Quantite: ${item.quantity || 1}</p>
                  <p>${item.reference || item.category || ""}</p>
                  <p><span class="status-pill" data-status="${item.status || "a-acheter"}">${partStatusLabel(item.status || "a-acheter")}</span></p>
                  <p>${item.link || ""}</p>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucun achat restant.</div>'}
        </div>
      `;
      return;
    }

    if (vehicle.activeTab === "consumables") {
      body.innerHTML = `
        <form class="vehicle-form" id="consumable-form">
          <input name="name" placeholder="Article" required />
          <input name="quantity" placeholder="Quantite" />
          <select name="category">
            <option value="fluide">Fluide</option>
            <option value="filtre">Filtre</option>
            <option value="ampoule">Ampoule</option>
            <option value="visserie">Visserie</option>
            <option value="clip">Clip / agrafe</option>
            <option value="joint">Joint</option>
            <option value="nettoyage">Nettoyage</option>
            <option value="peinture">Peinture</option>
            <option value="abrasif">Abrasif</option>
            <option value="autre">Autre</option>
          </select>
          <select name="status">
            <option value="a-acheter">A acheter</option>
            <option value="commande">Commande</option>
            <option value="recu">Recu</option>
            <option value="utilise">Utilise</option>
          </select>
          <input name="estimatedPrice" type="number" min="0" step="0.01" placeholder="Prix estime" />
          <input name="link" placeholder="Lien achat" />
          <input name="notes" placeholder="Notes" />
          <button class="primary-button" type="submit">Ajouter</button>
        </form>
        <div class="vehicle-cards">
          ${vehicle.consumables
            .filter((item) => matchesVehicleFilters(item, "stock"))
            .map(
              (item) => `
                <article class="vehicle-card">
                  <h4>${item.name}</h4>
                  <p>${item.category} / ${item.quantity || ""}</p>
                  <p><span class="status-pill" data-status="${item.status}">${partStatusLabel(item.status)}</span></p>
                  <p>${money(item.estimatedPrice)}</p>
                  <p>${item.notes || ""}</p>
                  <button type="button" data-edit-consumable="${item.id}">Editer</button>
                  <button type="button" data-delete-consumable="${item.id}">Supprimer</button>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucun article ajoute.</div>'}
        </div>
      `;
      renderFilterBar(body, "stock");

      document.querySelector("#consumable-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(event.target);
        vehicle.consumables.push({
          id: createId("consumable"),
          name: String(data.get("name")).trim(),
          quantity: String(data.get("quantity") || "").trim(),
          category: String(data.get("category")),
          status: String(data.get("status")),
          estimatedPrice: Number(data.get("estimatedPrice") || 0),
          link: String(data.get("link") || "").trim(),
          notes: String(data.get("notes") || "").trim(),
        });
        addHistory("consumable", `Stock ajoute: ${String(data.get("name")).trim()}`);
        await saveVehicle();
        render();
      });

      body.querySelectorAll("[data-delete-consumable]").forEach((button) => {
        button.addEventListener("click", async () => {
          vehicle.consumables = vehicle.consumables.filter((item) => item.id !== button.dataset.deleteConsumable);
          addHistory("consumable", "Stock supprime");
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-edit-consumable]").forEach((button) => {
        button.addEventListener("click", () => editConsumable(button.dataset.editConsumable));
      });
      return;
    }

    if (vehicle.activeTab === "planning") {
      body.innerHTML = `
        <div class="vehicle-cards">
          ${vehicle.stages
            .map(
              (stage) => `
                <article class="vehicle-card vehicle-card--stage">
                  <h4>${stage.label}</h4>
                  <select data-stage-status="${stage.id}">
                    <option value="a-faire" ${stage.status === "a-faire" ? "selected" : ""}>A faire</option>
                    <option value="en-cours" ${stage.status === "en-cours" ? "selected" : ""}>En cours</option>
                    <option value="fait" ${stage.status === "fait" ? "selected" : ""}>Fait</option>
                    <option value="bloque" ${stage.status === "bloque" ? "selected" : ""}>Bloque</option>
                  </select>
                  <span class="status-pill" data-status="${stage.status || "a-faire"}">${jobStatusLabel(stage.status || "a-faire")}</span>
                  <textarea data-stage-notes="${stage.id}" placeholder="Notes">${stage.notes || ""}</textarea>
                </article>
              `,
            )
            .join("")}
        </div>
      `;

      body.querySelectorAll("[data-stage-status]").forEach((select) => {
        select.addEventListener("change", async () => {
          const stage = vehicle.stages.find((entry) => entry.id === select.dataset.stageStatus);
          stage.status = select.value;
          addHistory("planning", `Etape mise a jour: ${stage.label}`);
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-stage-notes]").forEach((textarea) => {
        textarea.addEventListener("change", async () => {
          const stage = vehicle.stages.find((entry) => entry.id === textarea.dataset.stageNotes);
          stage.notes = textarea.value;
          await saveVehicle();
        });
      });
      return;
    }

    if (vehicle.activeTab === "photos") {
      body.innerHTML = `
        <form class="vehicle-form" id="photo-form">
          <input name="label" placeholder="Titre photo" required />
          <input name="url" placeholder="Chemin ou URL de la photo" required />
          <select name="linkedTo">
            <option value="">Lie a rien</option>
            ${linkedOptions()
              .map((option) => {
                const [type, id, label] = option.split(":");
                return `<option value="${type}:${id}">${type} - ${label}</option>`;
              })
              .join("")}
          </select>
          <select name="category">
            <option value="avant">Avant</option>
            <option value="apres">Apres</option>
            <option value="piece">Piece</option>
            <option value="travail">Travail</option>
          </select>
          <input name="notes" placeholder="Annotation" />
          <button class="primary-button" type="submit">Ajouter</button>
        </form>
        <div class="vehicle-cards">
          ${vehicle.photos
            .map(
              (photo) => `
                <article class="vehicle-card">
                  <h4>${photo.label}</h4>
                  <p>${photo.category}</p>
                  <p>${photo.linkedTo || ""}</p>
                  <p>${photo.url}</p>
                  <p>${photo.notes || ""}</p>
                  <button type="button" data-edit-photo="${photo.id}">Editer</button>
                  <button type="button" data-delete-photo="${photo.id}">Supprimer</button>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucune photo ajoutee.</div>'}
        </div>
      `;

      document.querySelector("#photo-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(event.target);
        vehicle.photos.push({
          id: createId("photo"),
          label: String(data.get("label")).trim(),
          url: String(data.get("url")).trim(),
          linkedTo: String(data.get("linkedTo") || ""),
          category: String(data.get("category")),
          notes: String(data.get("notes") || "").trim(),
        });
        await saveVehicle();
        render();
      });

      body.querySelectorAll("[data-delete-photo]").forEach((button) => {
        button.addEventListener("click", async () => {
          vehicle.photos = vehicle.photos.filter((photo) => photo.id !== button.dataset.deletePhoto);
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-edit-photo]").forEach((button) => {
        button.addEventListener("click", () => editPhoto(button.dataset.editPhoto));
      });
      return;
    }

    if (vehicle.activeTab === "documents") {
      body.innerHTML = `
        <form class="vehicle-form" id="document-form">
          <input name="label" placeholder="Nom document" required />
          <input name="url" placeholder="Chemin ou URL" required />
          <select name="type">
            <option value="facture">Facture</option>
            <option value="reference">Reference</option>
            <option value="manuel">Manuel</option>
            <option value="schema">Schema</option>
            <option value="autre">Autre</option>
          </select>
          <input name="notes" placeholder="Notes" />
          <button class="primary-button" type="submit">Ajouter</button>
        </form>
        <div class="vehicle-cards">
          ${vehicle.documents
            .map(
              (doc) => `
                <article class="vehicle-card">
                  <h4>${doc.label}</h4>
                  <p>${doc.type}</p>
                  <p>${doc.url}</p>
                  <p>${doc.notes || ""}</p>
                  <button type="button" data-edit-document="${doc.id}">Editer</button>
                  <button type="button" data-delete-document="${doc.id}">Supprimer</button>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucun document ajoute.</div>'}
        </div>
      `;
      document.querySelector("#document-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(event.target);
        vehicle.documents.push({
          id: createId("doc"),
          label: String(data.get("label")).trim(),
          url: String(data.get("url")).trim(),
          type: String(data.get("type")),
          notes: String(data.get("notes") || "").trim(),
        });
        addHistory("document", `Document ajoute: ${String(data.get("label")).trim()}`);
        await saveVehicle();
        render();
      });
      body.querySelectorAll("[data-delete-document]").forEach((button) => {
        button.addEventListener("click", async () => {
          vehicle.documents = vehicle.documents.filter((doc) => doc.id !== button.dataset.deleteDocument);
          addHistory("document", "Document supprime");
          await saveVehicle();
          render();
        });
      });
      body.querySelectorAll("[data-edit-document]").forEach((button) => {
        button.addEventListener("click", () => editDocument(button.dataset.editDocument));
      });
      return;
    }

    if (vehicle.activeTab === "history") {
      body.innerHTML = `
        <div class="vehicle-cards">
          ${vehicle.history
            .map(
              (entry) => `
                <article class="vehicle-card">
                  <h4>${entry.label}</h4>
                  <p>${entry.type}</p>
                  <p>${new Date(entry.date).toLocaleString("fr-FR")}</p>
                </article>
              `,
            )
            .join("") || '<div class="empty-state">Aucun historique pour le moment.</div>'}
        </div>
      `;
      return;
    }

    if (vehicle.activeTab === "export") {
      const exportText = [
        `Projet: ${vehicle.name}`,
        "",
        "Pieces importantes:",
        ...vehicle.parts
          .filter((part) => ["securite", "controle-technique"].includes(part.priority) || part.urgency === "bloquant")
          .map((part) => `- ${part.name} (${partStatusLabel(part.status || "a-acheter")})`),
        "",
        "Travaux restants:",
        ...vehicle.jobs
          .filter((job) => job.status !== "fait")
          .map((job) => `- ${job.title} (${jobStatusLabel(job.status || "a-faire")})`),
        "",
        "Controle technique:",
        ...vehicle.inspection.map((item) => `- ${item.label}: ${inspectionStatusLabel(item.status)}`),
      ].join("\n");

      body.innerHTML = `
        <div class="vehicle-export">
          <label for="vehicle-export-text">Resume imprimable</label>
          <textarea id="vehicle-export-text" readonly>${escapeHtml(exportText)}</textarea>
          <label for="vehicle-export-json">JSON du projet</label>
          <textarea id="vehicle-export-json" readonly>${escapeHtml(JSON.stringify(vehicle, null, 2))}</textarea>
          <button class="primary-button" type="button" id="copy-export">Copier le resume</button>
          <p class="save-status" id="export-status"></p>
        </div>
      `;

      body.querySelector("#copy-export").addEventListener("click", async () => {
        await navigator.clipboard.writeText(exportText);
        body.querySelector("#export-status").textContent = "Resume copie.";
      });
      return;
    }

    if (vehicle.activeTab === "import") {
      body.innerHTML = `
        <form class="vehicle-import" id="vehicle-import-form">
          <label for="vehicle-import-note">Coller la note de renovation</label>
          <textarea id="vehicle-import-note" placeholder="PIECE A CHANGER / ACHETER : ..."></textarea>
          <p>Importe automatiquement les pieces, travaux et controles sans supprimer les donnees existantes.</p>
          <button class="primary-button" type="submit">Importer</button>
        </form>
      `;
      document.querySelector("#vehicle-import-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const text = document.querySelector("#vehicle-import-note").value;
        parseVehicleNote(text);
        await saveVehicle();
        vehicle.activeTab = "summary";
        render();
      });
      return;
    }

    body.innerHTML = `
      <div class="budget-grid">
        <div><span>Score CT</span><strong>${vehicle.inspection.length ? Math.round((vehicle.inspection.filter((item) => item.status === "ok").length / vehicle.inspection.length) * 100) : 0}%</strong></div>
        <div><span>OK</span><strong>${vehicle.inspection.filter((item) => item.status === "ok").length}</strong></div>
        <div><span>A corriger</span><strong>${vehicle.inspection.filter((item) => item.status === "to_fix").length}</strong></div>
        <div><span>Bloquant</span><strong>${vehicle.inspection.filter((item) => item.status === "blocking").length}</strong></div>
        <div><span>A verifier</span><strong>${vehicle.inspection.filter((item) => item.status === "check").length}</strong></div>
      </div>
      <div class="inspection-list">
        ${vehicle.inspection
          .map(
            (item) => `
              <article class="inspection-item">
                <strong>${item.label}</strong>
                <select data-inspection-status="${item.id}">
                  <option value="ok" ${item.status === "ok" ? "selected" : ""}>OK</option>
                  <option value="to_fix" ${item.status === "to_fix" ? "selected" : ""}>A corriger</option>
                  <option value="blocking" ${item.status === "blocking" ? "selected" : ""}>Bloquant</option>
                  <option value="check" ${item.status === "check" ? "selected" : ""}>A verifier</option>
                </select>
                <span class="status-pill" data-status="${item.status}">${inspectionStatusLabel(item.status)}</span>
                <input data-inspection-notes="${item.id}" value="${item.notes || ""}" placeholder="Notes" />
              </article>
            `,
          )
          .join("")}
      </div>
    `;

    body.querySelectorAll("[data-inspection-status]").forEach((select) => {
      select.addEventListener("change", async () => {
        const item = vehicle.inspection.find((entry) => entry.id === select.dataset.inspectionStatus);
        item.status = select.value;
        await saveVehicle();
      });
    });
    body.querySelectorAll("[data-inspection-notes]").forEach((input) => {
      input.addEventListener("change", async () => {
        const item = vehicle.inspection.find((entry) => entry.id === input.dataset.inspectionNotes);
        item.notes = input.value;
        await saveVehicle();
      });
    });
  }

  render();
}

function renderPages() {
  const folder = getActiveFolder();
  const page = getActivePage();
  pageList.innerHTML = "";

  if (!folder) {
    pageList.innerHTML = '<div class="empty-state">Aucun dossier selectionne.</div>';
    return;
  }

  if (!page) {
    renderPageCards(folder);
    return;
  }

  if (page.type === "note") {
    renderNoteEditor(page);
    return;
  }

  if (page.type === "vehicle") {
    renderVehicleEditor(page);
    return;
  }

  renderTodoEditor(page);
}

function setHeader(folder, page = null) {
  currentFolder.textContent = page ? page.title : folder.name;
  folderDescription.textContent = page
    ? `${folder.name} / ${pageTypeLabels[page.type]}`
    : folder.description;
}

function selectFolder(folderId) {
  const folder = folders.find((item) => item.id === folderId);
  activePageId = null;

  if (!folder) {
    currentFolder.textContent = "Aucun dossier";
    folderDescription.textContent = "Creez un dossier pour commencer.";
    activeFolderId = null;
    renderFolders();
    renderPages();
    return;
  }

  activeFolderId = folder.id;
  setHeader(folder);
  renderFolders();
  renderPages();
}

function selectPage(folderId, pageId) {
  const folder = folders.find((item) => item.id === folderId);
  const page = folder?.pages.find((item) => item.id === pageId);

  if (!folder || !page) {
    return;
  }

  activeFolderId = folderId;
  activePageId = pageId;
  setHeader(folder, page);
  renderFolders();
  renderPages();
}

async function promptAuthentication() {
  if (authPromise) {
    return authPromise;
  }

  openAuthentication("login");

  authPromise = new Promise((resolve) => {
    authResolve = resolve;
  });

  return authPromise;
}

function setAuthMode(mode) {
  authMode = mode;
  const isRegister = authMode === "register";
  authTitle.textContent = isRegister ? "Inscription" : "Connexion";
  authSubmit.textContent = isRegister ? "Creer le compte" : "Se connecter";
  toggleAuthMode.textContent = isRegister ? "J'ai deja un compte" : "Creer un compte";
  authModal.querySelectorAll(".auth-register-field").forEach((element) => {
    element.hidden = !isRegister;
  });
  authEmail.required = isRegister;
  setMessage(authMessage, "");
}

function openAuthentication(mode = "login") {
  setAuthMode(mode);
  authModal.classList.add("is-open");
  authModal.setAttribute("aria-hidden", "false");
  setMessage(authMessage, "");
  window.setTimeout(() => authUsername.focus(), 0);
}

function closeAuthentication() {
  authModal.classList.remove("is-open");
  authModal.setAttribute("aria-hidden", "true");
  authPassword.value = "";
  authEmail.value = "";
  authPromise = null;
  authResolve = null;
}

async function login(username, password) {
  const response = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Connexion impossible.");
  }

  return result;
}

async function register(username, password, email) {
  const response = await fetch("/api/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, email }),
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Inscription impossible.");
  }

  return result;
}

function updateAuthNavigation() {
  authNavButton.textContent = currentUser ? "Dashboard" : "Connexion / inscription";
  authNavButton.hidden = false;
  navDashboardButton.hidden = true;
  logoutButton.hidden = !currentUser;
  navUserName.hidden = !currentUser;
  navUserName.textContent = currentUser?.username || "";
  dashboardTitle.textContent = currentUser
    ? `Bonjour ${currentUser.username}`
    : "Ton espace de travail";
}

function showView(view) {
  homePage.classList.toggle("is-hidden", view !== "home");
  dashboardPage.classList.toggle("is-hidden", view !== "dashboard");
  appShell.classList.toggle("is-hidden", view !== "projects");
  navHomeButton.classList.toggle("is-active", view === "home");
  navDashboardButton.classList.toggle("is-active", view === "dashboard");
}

function updateDashboardStats() {
  const pages = folders.flatMap((folder) => folder.pages || []);
  statFolders.textContent = String(folders.length);
  statVehicles.textContent = String(pages.filter((page) => page.type === "vehicle").length);
  statTodolists.textContent = String(pages.filter((page) => page.type === "todolist").length);
}

async function checkSession() {
  try {
    const response = await fetch("/api/auth/me");
    if (!response.ok) return null;
    const data = await parseJsonResponse(response);
    currentUser = data.user;
    updateAuthNavigation();
    return currentUser;
  } catch {
    return null;
  }
}

async function openDashboard() {
  if (!currentUser) {
    await promptAuthentication();
  }
  if (!projectsLoaded) {
    await loadFolders();
    projectsLoaded = true;
  }
  updateDashboardStats();
  showView("dashboard");
}

async function openProjects() {
  if (!currentUser) {
    await promptAuthentication();
  }

  showView("projects");

  if (!projectsLoaded) {
    await loadFolders();
    projectsLoaded = true;
  }
  updateDashboardStats();
}

async function logout() {
  await fetch("/api/auth/logout", { method: "POST" });
  currentUser = null;
  folders = [];
  projectsLoaded = false;
  activeFolderId = null;
  activePageId = null;
  updateDashboardStats();
  updateAuthNavigation();
  showView("home");
}

async function loadFolders() {
  let response = await fetch("/api/folders");

  if (response.status === 401) {
    await promptAuthentication();
    response = await fetch("/api/folders");
  }

  if (!response.ok) {
    throw new Error("Impossible de charger les dossiers.");
  }

  folders = (await parseJsonResponse(response)).map(normalizeFolder);
  updateDashboardStats();
  selectFolder(folders[0]?.id);
}

async function createFolder(name) {
  const response = await fetch("/api/folders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name }),
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Impossible de creer le dossier.");
  }

  folders.push(normalizeFolder(result));
  updateDashboardStats();
  selectFolder(result.id);
}

async function renameFolder(folderId) {
  const folder = folders.find((item) => item.id === folderId);
  const name = window.prompt("Nouveau nom du dossier", folder?.name || "");

  if (!folder || !name?.trim()) {
    return;
  }

  const response = await fetch(`/api/folders/${encodeURIComponent(folderId)}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name: name.trim() }),
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    window.alert(result.error || "Impossible de renommer le dossier.");
    return;
  }

  Object.assign(folder, normalizeFolder(result));
  setHeader(folder, getActivePage());
  renderFolders();
}

async function deleteFolder(folderId) {
  const response = await fetch(`/api/folders/${encodeURIComponent(folderId)}`, {
    method: "DELETE",
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Impossible de supprimer le dossier.");
  }

  folders = folders.filter((folder) => folder.id !== folderId);
  activePageId = null;
  updateDashboardStats();

  if (activeFolderId === folderId) {
    selectFolder(folders[0]?.id);
  } else {
    renderFolders();
  }
}

async function renamePage(folderId, pageId) {
  const folder = folders.find((item) => item.id === folderId);
  const page = folder?.pages.find((item) => item.id === pageId);
  const title = window.prompt("Nouveau nom de la page", page?.title || "");

  if (!folder || !page || !title?.trim()) {
    return;
  }

  const updatedPage = await updatePage(folderId, pageId, { title: title.trim() });
  Object.assign(page, updatedPage);

  if (activeFolderId === folderId && activePageId === pageId) {
    setHeader(folder, page);
  }

  renderFolders();
  renderPages();
}

async function deletePage(folderId, pageId) {
  const folder = folders.find((item) => item.id === folderId);
  const page = folder?.pages.find((item) => item.id === pageId);

  if (!folder || !page || !window.confirm(`Supprimer la page "${page.title}" ?`)) {
    return;
  }

  const response = await fetch(
    `/api/folders/${encodeURIComponent(folderId)}/pages/${encodeURIComponent(pageId)}`,
    { method: "DELETE" },
  );
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    window.alert(result.error || "Impossible de supprimer la page.");
    return;
  }

  folder.pages = folder.pages.filter((item) => item.id !== pageId);
  updateDashboardStats();

  if (activeFolderId === folderId && activePageId === pageId) {
    selectFolder(folderId);
  } else {
    renderFolders();
    renderPages();
  }
}

async function createPage(folderId, page) {
  const response = await fetch(`/api/folders/${encodeURIComponent(folderId)}/pages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(page),
  });
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Impossible de creer la page.");
  }

  const folder = folders.find((item) => item.id === folderId);
  folder.pages.push(result);
  updateDashboardStats();
  selectPage(folderId, result.id);
}

async function updatePage(folderId, pageId, patch) {
  const response = await fetch(
    `/api/folders/${encodeURIComponent(folderId)}/pages/${encodeURIComponent(pageId)}`,
    {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(patch),
    },
  );
  const result = await parseJsonResponse(response);

  if (!response.ok) {
    throw new Error(result.error || "Impossible de sauvegarder la page.");
  }

  const folder = folders.find((item) => item.id === folderId);
  const pageIndex = folder.pages.findIndex((page) => page.id === pageId);
  folder.pages[pageIndex] = result;
  return result;
}

async function saveTodos(todos) {
  const status = document.querySelector("#save-status");
  status.textContent = "Sauvegarde...";

  try {
    await updatePage(activeFolderId, activePageId, { content: todos });
    status.textContent = "Sauvegarde";
  } catch (error) {
    status.textContent = error.message;
    status.classList.add("is-error");
    throw error;
  }
}

function openModal() {
  createFolderModal.classList.add("is-open");
  createFolderModal.setAttribute("aria-hidden", "false");
  createFolderForm.reset();
  setMessage(formMessage, "");
  window.setTimeout(() => folderNameInput.focus(), 0);
}

function closeModal() {
  createFolderModal.classList.remove("is-open");
  createFolderModal.setAttribute("aria-hidden", "true");
  openCreateFolderModal.focus();
}

function openCreatePageModal(folderId) {
  const folder = folders.find((item) => item.id === folderId);

  if (!folder) {
    return;
  }

  pageTargetFolderId = folderId;
  addFolderItemTitle.textContent = folder.name;
  addFolderItemModal.classList.add("is-open");
  addFolderItemModal.setAttribute("aria-hidden", "false");
  createPageForm.reset();
  setMessage(pageFormMessage, "");
  window.setTimeout(() => pageTitleInput.focus(), 0);
}

function closeCreatePageModal() {
  addFolderItemModal.classList.remove("is-open");
  addFolderItemModal.setAttribute("aria-hidden", "true");
  pageTargetFolderId = null;
}

function openDeleteFolderModal(folderId) {
  const folder = folders.find((item) => item.id === folderId);

  if (!folder) {
    return;
  }

  deleteTargetFolderId = folderId;
  deleteFolderCopy.textContent = `Le dossier "${folder.name}" et ses pages seront supprimes.`;
  setMessage(deleteFolderMessage, "");
  deleteFolderModal.classList.add("is-open");
  deleteFolderModal.setAttribute("aria-hidden", "false");
  window.setTimeout(() => confirmDeleteFolder.focus(), 0);
}

function closeDeleteFolderModal() {
  deleteFolderModal.classList.remove("is-open");
  deleteFolderModal.setAttribute("aria-hidden", "true");
  deleteTargetFolderId = null;
}

function findTodoInBoard(categoryId, todoId) {
  const category = activeTodoBoard?.categories.find((item) => item.id === categoryId);
  const todo = category?.todos.find((item) => item.id === todoId);

  if (!category || !todo) {
    return null;
  }

  return { category, todo };
}

function openTodoDetailModal(categoryId, todoId) {
  const result = findTodoInBoard(categoryId, todoId);

  if (!result) {
    return;
  }

  todoDetailTarget = { categoryId, todoId };
  todoDetailText.value = result.todo.text;
  todoDetailStatus.value = result.todo.status;
  todoDetailSize.value = result.todo.size || "medium";
  todoDetailDescription.value = result.todo.description || "";
  setMessage(todoDetailMessage, "");
  todoDetailModal.classList.add("is-open");
  todoDetailModal.setAttribute("aria-hidden", "false");
  window.setTimeout(() => todoDetailText.focus(), 0);
}

function closeTodoDetailModal() {
  todoDetailModal.classList.remove("is-open");
  todoDetailModal.setAttribute("aria-hidden", "true");
  todoDetailTarget = null;
}

toggleSidebar.addEventListener("click", () => {
  const isCollapsed = appShell.classList.toggle("is-sidebar-collapsed");
  toggleSidebar.setAttribute(
    "aria-label",
    isCollapsed ? "Deplier le menu" : "Rabattre le menu",
  );
  toggleSidebar.title = isCollapsed ? "Deplier le menu" : "Rabattre le menu";
});

openCreateFolderModal.addEventListener("click", openModal);

createFolderModal.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-modal")) {
    closeModal();
  }
});

addFolderItemModal.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-add-modal")) {
    closeCreatePageModal();
  }
});

deleteFolderModal.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-delete-modal")) {
    closeDeleteFolderModal();
  }
});

todoDetailModal.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-todo-detail")) {
    closeTodoDetailModal();
  }
});

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const username = authUsername.value.trim();
  const email = authEmail.value.trim();
  const password = authPassword.value;
  const submitButton = authForm.querySelector("button[type='submit']");

  if (!username || !password) {
    setMessage(authMessage, "Nom utilisateur et mot de passe requis.", true);
    return;
  }

  submitButton.disabled = true;
  setMessage(authMessage, "Connexion...");

  try {
    const result =
      authMode === "register"
        ? await register(username, password, email)
        : await login(username, password);
    currentUser = result.user;
    updateAuthNavigation();
    authResolve?.();
    closeAuthentication();
    await openDashboard();
  } catch (error) {
    setMessage(authMessage, error.message, true);
    authPassword.select();
  } finally {
    submitButton.disabled = false;
  }
});

toggleAuthMode.addEventListener("click", () => {
  setAuthMode(authMode === "login" ? "register" : "login");
});

cancelAuth.addEventListener("click", () => {
  closeAuthentication();
});

brandHomeButton.addEventListener("click", () => {
  showView("home");
});

navHomeButton.addEventListener("click", () => {
  showView("home");
});

navDashboardButton.addEventListener("click", () => {
  openDashboard().catch((error) => {
    currentFolder.textContent = "Erreur";
    folderDescription.textContent = error.message;
  });
});

authNavButton.addEventListener("click", async () => {
  if (currentUser) {
    await openDashboard();
    return;
  }

  openAuthentication("login");
});

homeAuthButton.addEventListener("click", () => {
  openAuthentication("login");
});

logoutButton.addEventListener("click", () => {
  logout().catch((error) => {
    window.alert(error.message);
  });
});

backDashboardButton.addEventListener("click", () => {
  openDashboard().catch((error) => {
    currentFolder.textContent = "Erreur";
    folderDescription.textContent = error.message;
  });
});

openProjectDashboard.addEventListener("click", () => {
  openProjects().catch((error) => {
    currentFolder.textContent = "Erreur";
    folderDescription.textContent = error.message;
  });
});

createFolderForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const folderName = folderNameInput.value.trim();

  if (!folderName) {
    setMessage(formMessage, "Le nom du dossier est obligatoire.", true);
    return;
  }

  try {
    await createFolder(folderName);
    closeModal();
  } catch (error) {
    setMessage(formMessage, error.message, true);
  }
});

createPageForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!pageTargetFolderId) {
    return;
  }

  const formData = new FormData(createPageForm);
  const title = String(formData.get("title") || "").trim();
  const type = String(formData.get("type") || "note");

  if (!title) {
    setMessage(pageFormMessage, "Le nom de la page est obligatoire.", true);
    return;
  }

  try {
    await createPage(pageTargetFolderId, { title, type });
    closeCreatePageModal();
  } catch (error) {
    setMessage(pageFormMessage, error.message, true);
  }
});

confirmDeleteFolder.addEventListener("click", async () => {
  if (!deleteTargetFolderId) {
    return;
  }

  try {
    await deleteFolder(deleteTargetFolderId);
    closeDeleteFolderModal();
  } catch (error) {
    setMessage(deleteFolderMessage, error.message, true);
  }
});

todoDetailForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!todoDetailTarget) {
    return;
  }

  const result = findTodoInBoard(todoDetailTarget.categoryId, todoDetailTarget.todoId);

  if (!result) {
    closeTodoDetailModal();
    return;
  }

  const text = todoDetailText.value.trim();

  if (!text) {
    setMessage(todoDetailMessage, "Le titre est obligatoire.", true);
    return;
  }

  result.todo.text = text;
  result.todo.status = todoDetailStatus.value;
  result.todo.done = result.todo.status === "done";
  result.todo.size = todoDetailSize.value;
  result.todo.description = todoDetailDescription.value.trim();

  try {
    await saveTodos(activeTodoBoard);
    activeTodoDraw?.();
    closeTodoDetailModal();
  } catch (error) {
    setMessage(todoDetailMessage, error.message, true);
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") {
    return;
  }

  if (createFolderModal.classList.contains("is-open")) {
    closeModal();
  }

  if (addFolderItemModal.classList.contains("is-open")) {
    closeCreatePageModal();
  }

  if (deleteFolderModal.classList.contains("is-open")) {
    closeDeleteFolderModal();
  }

  if (todoDetailModal.classList.contains("is-open")) {
    closeTodoDetailModal();
  }
});

async function initializeApp() {
  showView("home");
  setAuthMode("login");
  await checkSession();
}

initializeApp().catch((error) => {
  currentFolder.textContent = "Erreur";
  folderDescription.textContent = error.message;
});
